import React from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useCurrentUser, firebaseAuth } from "app"; // Added firebaseAuth and useCurrentUser

export default function App() {
  const navigate = useNavigate();
  const { user, loading } = useCurrentUser(); // Get current user state

  const handleGetStarted = () => {
    // Navigate to dashboard or login page based on auth state
    if (user) {
      navigate("/dashboard"); // Navigate to a future dashboard page
    } else {
      navigate("/login");
    }
  };

  const handleLogout = async () => {
    try {
      await firebaseAuth.signOut();
      // Optional: navigate to home or login page after logout
      navigate("/");
    } catch (error) {
      console.error("Logout failed:", error);
      // Handle logout error (e.g., show a notification)
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-4">
      {/* User Info and Logout Button Top Right */}
      {(user && !loading) && (
        <div className="absolute top-4 right-4 flex items-center space-x-4">
          <span className="text-sm text-muted-foreground">{user.email}</span>
          <Button variant="outline" size="sm" onClick={handleLogout}>
            Logout
          </Button>
        </div>
      )}

      <div className="flex flex-col items-center justify-center pt-16 sm:pt-24">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">checkmate.ai</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Unlock insights from your Lichess games. Understand your play, your way.
          </p>
          {/* Hide Get Started button if user is logged in, or change its behavior */}
          {(!user && !loading) && (
            <Button onClick={handleGetStarted} size="lg">
              Get Started / Login
            </Button>
          )}
          {(user && !loading) && (
             <Button onClick={() => navigate("/dashboard")} size="lg">
              Go to Dashboard
            </Button>
          )}
        </header>

        <main className="container mx-auto px-4 text-center">
          <section className="mb-12">
            <h2 className="text-3xl font-semibold mb-4">How It Works</h2>
            <p className="text-lg max-w-2xl mx-auto text-muted-foreground">
              Connect your Lichess account, and our AI will analyze your games. For the casual players tired of analytics dashboards, our AI-powered chess coach can help you improve without decoding complex chess jargon.
            </p>
          </section>

          <section>
            <h2 className="text-3xl font-semibold mb-4">Why checkmate.ai?</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="p-6 rounded-lg">
                <h3 className="text-2xl font-semibold mb-2">AI-Powered Analysis</h3>
                <p className="text-muted-foreground">
                  Leverage the power of LLMs to understand your chess patterns like never before.
                </p>
              </div>
              <div className="p-6 rounded-lg">
                <h3 className="text-2xl font-semibold mb-2">Simple Explanations</h3>
                <p className="text-muted-foreground">
                  No more confusing chess terminology. Get insights in plain English.
                </p>
              </div>
              <div className="p-6 rounded-lg">
                <h3 className="text-2xl font-semibold mb-2">Focus on Your Game</h3>
                <p className="text-muted-foreground">
                  Spend less time studying and more time playing and improving.
                </p>
              </div>
            </div>
          </section>
        </main>

        <footer className="text-center mt-12 py-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} checkmate.ai - All Rights Reserved
          </p>
        </footer>
      </div>
    </div>
  );
}
