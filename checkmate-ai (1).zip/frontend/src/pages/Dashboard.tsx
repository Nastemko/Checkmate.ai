import { HelpCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import React, { useState, useEffect, useRef } from "react";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import brain from "brain";
import { Game as LichessGame, GamesResponse, ChatMessage as ApiChatMessage, ChatMessagePart } from "types"; 
import { useCurrentUser } from "app"; 
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ChessboardVisualization } from "components/ChessboardVisualization";
import rehypeRaw from 'rehype-raw';

// Helper function to determine player color and opponent
const getPlayerPerspective = (game: LichessGame, inputUsername: string) => {
  const lowerInputUsername = inputUsername.toLowerCase();
  let playerColor: "white" | "black" | "unknown" = "unknown";
  let opponentUsername = "N/A";

  if (game.players.white.user?.name?.toLowerCase() === lowerInputUsername) {
    playerColor = "white";
    opponentUsername = game.players.black.user?.name || "Anonymous";
  } else if (game.players.black.user?.name?.toLowerCase() === lowerInputUsername) {
    playerColor = "black";
    opponentUsername = game.players.white.user?.name || "Anonymous";
  }
  return { playerColor, opponentUsername };
};

// Helper function to determine game result for the player
const getPlayerResult = (game: LichessGame, playerColor: "white" | "black" | "unknown") => {
  if (playerColor === "unknown" || !game.status || game.status === "created" || game.status === "started") return "Ongoing/Unknown";
  if (game.status === "draw" || game.status === "stalemate") return "Draw";
  if (game.winner === playerColor) return "Win";
  if (game.winner && game.winner !== playerColor) return "Loss";
  // Handle other statuses like "abort", "timeout", "outoftime"
  if (game.status === "resign") {
    return game.winner === playerColor ? "Win (Resignation)" : "Loss (Resignation)";
  }
  if (game.status === "timeout" || game.status === "outoftime") {
    return game.winner === playerColor ? "Win (Time)" : "Loss (Time)";
  }
  if (game.status === "cheat") {
    return game.winner === playerColor ? "Win (Cheat)" : "Loss (Cheat)";
  }
  return game.status; // Default to the status if not a clear win/loss/draw for player
};

export default function Dashboard() {
  const [lichessUsername, setLichessUsername] = useState("Boatcrouchstem"); // Default for testing
  const [games, setGames] = useState<LichessGame[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useCurrentUser(); // Firebase user, not Lichess user directly

  const [selectedGameIds, setSelectedGameIds] = useState<string[]>([]);
  const [pgnVisibleGameIds, setPgnVisibleGameIds] = useState<string[]>([]);

  // State for Gemini Analysis (now part of chat messages)
  // const [analysisText, setAnalysisText] = useState<string | null>(null); // Deprecated
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  // const [analysisError, setAnalysisError] = useState<string | null>(null); // Deprecated

  // State for Chat
  const [messages, setMessages] = useState<Array<{ id: string; sender: "user" | "ai"; text: string; timestamp: Date; fen?: string }>>([]);
  const [userInput, setUserInput] = useState("");
  const chatScrollAreaRef = React.useRef<HTMLDivElement>(null);
  const [selectedTone, setSelectedTone] = useState<string>("Friendly & Casual");
  const [isChatProcessing, setIsChatProcessing] = useState<boolean>(false); // Added this line

  const toneOptions = [
    { value: "Friendly & Casual", label: "Friendly & Casual" },
    { value: "Simple & Direct", label: "Simple & Direct" },
    { value: "Encouraging Coach", label: "Encouraging Coach" },
    { value: "Technical & In-depth", label: "Technical & In-depth" },
  ];

  // Auto-scroll to bottom of chat
  React.useEffect(() => {
    if (chatScrollAreaRef.current) {
      chatScrollAreaRef.current.scrollTo({ top: chatScrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages]);

  const handleGameSelectToggle = (gameId: string) => {
    setSelectedGameIds(prevSelected =>
      prevSelected.includes(gameId)
        ? prevSelected.filter(id => id !== gameId)
        : [...prevSelected, gameId]
    );
  };

  const handlePgnVisibilityToggle = (gameId: string) => {
    setPgnVisibleGameIds(prevVisible =>
      prevVisible.includes(gameId)
        ? prevVisible.filter(id => id !== gameId)
        : [...prevVisible, gameId]
    );
  };

  const handleFetchGames = async () => {
    if (!lichessUsername.trim()) {
      toast.error("Please enter a Lichess username.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setGames([]);

    try {
      // The brain.get_user_games method name will be generated based on your FastAPI endpoint
      // It might be brain.lichessGetUserGames or similar. Let's assume brain.get_user_games for now.
      // Ensure you import the correct method from the generated brain client.
      const response = await brain.get_user_games({ username: lichessUsername, max_games: 5 });
      const data: GamesResponse = await response.json();
      
      if (response.ok) {
        if (data.games && data.games.length > 0) {
          setGames(data.games);
          toast.success(`Fetched ${data.count} games for ${data.username}`);
        } else {
          setGames([]);
          toast.info(`No games found for ${data.username}.`);
        }
      } else {
        // Try to parse error from backend if available
        const errorData = await response.json().catch(() => ({ detail: "Failed to fetch games. Invalid response from server." }));
        const errorMessage = errorData.detail || `Error ${response.status}: ${response.statusText}`;
        setError(errorMessage);
        toast.error(errorMessage);
      }
    } catch (err: any) {
      console.error("Failed to fetch games:", err);
      const message = err.message || "An unexpected error occurred.";
      setError(message);
      toast.error(message);
    }
    setIsLoading(false);
  };

  const handleAnalyzeGame = async () => {
    if (selectedGameIds.length === 0) {
      toast.info("Please select a game from the list to analyze.");
      return;
    }

    if (selectedGameIds.length > 2) {
      toast.error("Sorry! The ability to analyze more concurrent games will come soon!", {
        description: "Please select only one or two games for analysis at this time.",
        // dismissible: true, // sonner default is dismissible via click or swipe
        duration: 5000, 
      });
      return;
    }

    setIsAnalyzing(true);
    setMessages([]); // Clear previous messages to start a new analysis context

    // Ensure Message type is available (it's implicitly defined by useState)
    type Message = { id: string; sender: "user" | "ai"; text: string; timestamp: Date; fen?: string };
    let currentMessages: Message[] = []; // To build up history for the second call if needed

    const gamesToAnalyzeDetails = selectedGameIds
      .map(id => games.find(g => g.id === id))
      .filter(g => g && g.moves) as LichessGame[]; // Get full game objects with PGN

    if (gamesToAnalyzeDetails.length === 0 || gamesToAnalyzeDetails.length !== selectedGameIds.length) {
      toast.error("One or more selected games could not be found or are missing PGN data. Please refresh and try again.");
      setIsAnalyzing(false);
      return;
    }

    // --- Analyze the FIRST game ---
    const firstGame = gamesToAnalyzeDetails[0];
    const { playerColor: p1Color, opponentUsername: o1Name } = getPlayerPerspective(firstGame, lichessUsername);
    // const firebaseUserDisplayName = user?.displayName || user?.email || "Anonymous User"; // Removed for privacy
    
    let firstGamePromptText = `Please analyze the following PGN for me. I (Lichess: ${lichessUsername}) was playing as ${p1Color} against ${o1Name}.\n\nPGN:\n${firstGame.moves}`;
    if (gamesToAnalyzeDetails.length > 1) {
      firstGamePromptText = `I've selected two games for you to analyze and compare. First, please analyze this game. I (Lichess: ${lichessUsername}) was playing as ${p1Color} against ${o1Name}.\n\nPGN:\n${firstGame.moves}`;
    }
    
    const firstUserMessageForUi: Message = {
      id: `user-pgn1-${Date.now()}`,
      sender: "user",
      text: firstGamePromptText,
      timestamp: new Date(),
    };
    currentMessages.push(firstUserMessageForUi);
    setMessages([...currentMessages]); 
    setIsChatProcessing(true);

    try {
      const firstGamePayload = {
        message: firstGamePromptText,
        tone_preference: selectedTone,
        conversation_history: [], 
      };
      console.log("[DEBUG] Sending PGN analysis request (Game 1) to /chatwise-message-relay:", JSON.stringify(firstGamePayload, null, 2));
      const response1 = await brain.handle_chatwise_message_relay(firstGamePayload);
      const result1 = await response1.json();

      if (response1.ok && result1.reply) {
        const aiAnalysisMessage1: Message = {
          id: `ai-analysis1-${Date.now()}`,
          sender: "ai",
          text: result1.reply, 
          timestamp: new Date(),
        };
        currentMessages.push(aiAnalysisMessage1);
        setMessages([...currentMessages]);
        toast.success(`Analysis of game 1 (${firstGame.id}) complete.`);
      } else {
        const errorDetail1 = result1.detail || "Failed to get analysis for game 1.";
        const aiErrorMessage1: Message = {
          id: `error-analysis1-${Date.now()}`,
          sender: "ai",
          text: `Analysis for game 1 failed: ${errorDetail1}`,
          timestamp: new Date(),
        };
        currentMessages.push(aiErrorMessage1);
        setMessages([...currentMessages]);
        toast.error(`Analysis for game 1 failed: ${errorDetail1}`);
        setIsChatProcessing(false);
        setIsAnalyzing(false);
        return;
      }
    } catch (err: any) {
      console.error("Error during initial game analysis (Game 1):", err);
      const errorMessageText1 = err.message || "An unexpected error occurred during game 1 analysis.";
      const aiCatchErrorMessage1: Message = {
        id: `error-catch1-${Date.now()}`,
        sender: "ai",
        text: `Error (Game 1): ${errorMessageText1}`,
        timestamp: new Date(),
      };
      currentMessages.push(aiCatchErrorMessage1);
      setMessages([...currentMessages]);
      toast.error(errorMessageText1);
      setIsChatProcessing(false);
      setIsAnalyzing(false);
      return;
    }
    // Do not set isChatProcessing to false yet if a second game is coming

    // --- If a SECOND game was selected, analyze it now ---
    if (gamesToAnalyzeDetails.length > 1) {
      const secondGame = gamesToAnalyzeDetails[1];
      toast.info(`Now analyzing the second selected game: ${secondGame.id}`);
      
      const { playerColor: p2Color, opponentUsername: o2Name } = getPlayerPerspective(secondGame, lichessUsername);
      // const firebaseUserDisplayName = user?.displayName || user?.email || "Anonymous User"; // Removed for privacy
      const secondGamePromptText = `Thank you for the analysis of the first game. Now, please analyze this second game and compare its trends and mistakes with the first one. In this second game, I (Lichess: ${lichessUsername}) was playing as ${p2Color} against ${o2Name}.\n\nPGN:\n${secondGame.moves}`;

      const secondUserMessageForUi: Message = {
        id: `user-pgn2-${Date.now()}`,
        sender: "user",
        text: secondGamePromptText,
        timestamp: new Date(),
      };
      currentMessages.push(secondUserMessageForUi);
      setMessages([...currentMessages]);
      // isChatProcessing should still be true from the first call, or set it true if it somehow got to false
      if (!isChatProcessing) setIsChatProcessing(true);


      try {
          const apiHistoryForSecondCall: ApiChatMessage[] = currentMessages.slice(0, -1) // All messages *before* the current user prompt for game 2
              .map(msg => ({
                  role: msg.sender === "user" ? "user" : "model",
                  parts: [{ text: msg.text }],
              }));

          const secondGamePayload = {
              message: secondGamePromptText,
              tone_preference: selectedTone,
              conversation_history: apiHistoryForSecondCall,
          };
          console.log("[DEBUG] Sending PGN analysis request (Game 2) to /chatwise-message-relay:", JSON.stringify(secondGamePayload, null, 2));
          const response2 = await brain.handle_chatwise_message_relay(secondGamePayload);
          const result2 = await response2.json();

          if (response2.ok && result2.reply) {
              const aiAnalysisMessage2: Message = {
                id: `ai-analysis2-${Date.now()}`,
                sender: "ai",
                text: result2.reply,
                timestamp: new Date()
              };
              currentMessages.push(aiAnalysisMessage2);
              setMessages([...currentMessages]);
              toast.success(`Analysis of game 2 (${secondGame.id}) and comparison complete!`);
          } else {
              const errorDetail2 = result2.detail || "Failed to get analysis for game 2.";
              const aiErrorMessage2: Message = {
                id: `error-analysis2-${Date.now()}`,
                sender: "ai",
                text: `Analysis for game 2 failed: ${errorDetail2}`,
                timestamp: new Date(),
              };
              currentMessages.push(aiErrorMessage2);
              setMessages([...currentMessages]);
              toast.error(`Analysis for game 2 failed: ${errorDetail2}`);
          }
      } catch (err: any) {
          console.error("Error during game analysis (Game 2):", err);
          const errorMessageText2 = err.message || "An unexpected error occurred during game 2 analysis.";
          const aiCatchErrorMessage2: Message = {
            id: `error-catch2-${Date.now()}`,
            sender: "ai",
            text: `Error (Game 2): ${errorMessageText2}`,
            timestamp: new Date(),
          };
          currentMessages.push(aiCatchErrorMessage2);
          setMessages([...currentMessages]);
          toast.error(errorMessageText2);
      } finally {
          setIsChatProcessing(false);
          setIsAnalyzing(false); 
      }
    } else {
        // Only one game was analyzed, or an error occurred before the second game
        setIsChatProcessing(false);
        setIsAnalyzing(false);
    }
  };

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const newUserMessage: Message = {
      id: `user-${Date.now()}`,
      sender: "user" as "user", // Explicitly type as "user"
      text: userInput.trim(),
      timestamp: new Date(),
    };
    // Optimistically update UI with user's message
    setMessages(prevMessages => [...prevMessages, newUserMessage]);
    const currentInput = userInput.trim();
    setUserInput(""); // Clear input after sending

    // Prepare conversation history for the API
    // The API expects roles "user" or "model" and parts: [{text: string}]
    const apiHistory: ApiChatMessage[] = messages.map(msg => ({
      role: msg.sender === "user" ? "user" : "model",
      parts: [{ text: msg.text }],
      // Ensure you don't pass other fields like id or timestamp if not in ApiChatMessage
    }));

    // Temporarily adjust for simplified backend model
    const payload = {
      message: currentInput,
      tone_preference: selectedTone,
      conversation_history: apiHistory, // History is now in the correct Gemini format
    };
    console.log("[DEBUG] Sending to /chatwise-message-relay endpoint:", JSON.stringify(payload, null, 2));
    setIsChatProcessing(true);
    try {
      const response = await brain.generate_fen_for_visualization(payload);
      const result = await response.json();

      if (response.ok && result.reply) {
        const aiResponse = {
          id: `ai-${Date.now()}`,
          sender: "ai" as "ai",
          text: result.reply,
          timestamp: new Date(),
        };
        setMessages(prevMessages => [...prevMessages, aiResponse]);
      } else {
        const errorDetail = result.detail || "Failed to get response from AI.";
        toast.error(`Chat error: ${errorDetail}`);
        // Optionally add an error message to the chat interface
        const aiErrorResponse = {
          id: `error-${Date.now()}`,
          sender: "ai" as "ai",
          text: `Sorry, I encountered an error: ${errorDetail}`,
          timestamp: new Date(),
        };
        setMessages(prevMessages => [...prevMessages, aiErrorResponse]);
      }
    } catch (err: any) {
      console.error("Error sending message:", err);
      const message = err.message || "An unexpected error occurred.";
      toast.error(`Chat error: ${message}`);
      const aiErrorResponse = {
        id: `error-${Date.now()}`,
        sender: "ai" as "ai",
        text: `Sorry, an unexpected error occurred: ${message}`,
        timestamp: new Date(),
      };
      setMessages(prevMessages => [...prevMessages, aiErrorResponse]);
    } finally {
      setIsChatProcessing(false);
    }
  };

  const handleRequestVisualization = async () => {
    if (!userInput.trim()) {
      toast.info("Please describe what you want to see. For example, 'Show me the board after move 10.'");
      return;
    }

    const requestText = userInput.trim();
    const newUserMessage: Message = {
      id: `user-vis-${Date.now()}`,
      sender: "user",
      text: requestText,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, newUserMessage]);
    setUserInput("");
    setIsChatProcessing(true);

    // Prepare history, excluding the current request text itself from the user part
    const apiHistory: ApiChatMessage[] = [...messages]
      .map(msg => ({
        role: msg.sender === "user" ? "user" : "model",
        parts: [{ text: msg.text }],
      }));

    try {
      const payload = {
        message: requestText,
        conversation_history: apiHistory,
        tone_preference: selectedTone, // Not used by FEN endpoint, but part of the contract
      };
      const response = await brain.generate_fen_for_visualization(payload);
      const result = await response.json();

      if (response.ok && result.fen) {
        const aiResponse: Message = {
          id: `ai-vis-${Date.now()}`,
          sender: "ai",
          text: `Here is the board position you requested.`, // Accompanying text
          fen: result.fen, // Attach the FEN string here
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, aiResponse]);
      } else {
        const errorDetail = result.detail || "Failed to generate visualization.";
        toast.error(`Visualization error: ${errorDetail}`);
      }
    } catch (err: any) {
      console.error("Error requesting visualization:", err);
      toast.error(err.message || "An unexpected error occurred.");
    } finally {
      setIsChatProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground p-2 sm:p-4 gap-2 sm:gap-4">
      {/* Removed top header placeholder */}
      <ResizablePanelGroup
        direction="horizontal"
        className="flex-grow border rounded-lg overflow-hidden"
      >
        <ResizablePanel defaultSize={40} minSize={25} className="p-1 sm:p-2">
          <div className="flex flex-col h-full p-2 sm:p-4 rounded-md bg-muted/10">
            <h2 className="text-lg font-semibold mb-3 sm:mb-4">Recent Games</h2>
            {games.length > 0 && (
              <div className="flex items-center mb-2">
                <Checkbox
                  id="select-all-games"
                  checked={
                    games.length > 0 && selectedGameIds.length === games.length
                  }
                  onCheckedChange={() => {
                    if (selectedGameIds.length === games.length) {
                      setSelectedGameIds([]); // Deselect all
                    } else {
                      setSelectedGameIds(games.map(g => g.id)); // Select all
                    }
                  }}
                  aria-label="Select all games"
                  className="mr-2 border-slate-400 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                />
                <label htmlFor="select-all-games" className="text-sm text-muted-foreground cursor-pointer">
                  {selectedGameIds.length === games.length ? "Deselect All" : "Select All"}
                </label>
                <TooltipProvider delayDuration={100}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="ml-1.5 h-4 w-4 text-muted-foreground cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p className="text-sm">
                        Select one or two games from the list to analyze. If two are selected, they will be analyzed sequentially for comparison.
                        ({selectedGameIds.length} selected)
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            )}
            <div className="flex items-center gap-2 mb-3 sm:mb-4">
              <Input
                type="text"
                placeholder="Enter Lichess Username"
                value={lichessUsername}
                onChange={(e) => setLichessUsername(e.target.value)}
                className="flex-1 min-w-0"
                onKeyDown={(e) => e.key === 'Enter' && handleFetchGames()}
              />
              <Button onClick={handleFetchGames} disabled={isLoading} className="whitespace-nowrap text-xs h-7 px-2 py-1">
                {isLoading ? "Fetching..." : "Fetch"}
              </Button>
            </div>

            {error && (
              <div className="text-red-500 p-3 bg-red-500/10 rounded-md mb-3 sm:mb-4">
                <p>{error}</p>
              </div>
            )}

            {isLoading && games.length === 0 && (
              <div className="flex-grow flex items-center justify-center">
                <p className="text-muted-foreground">Loading games for {lichessUsername}...</p>
              </div>
            )}

            {!isLoading && !error && games.length === 0 && !lichessUsername && (
              <div className="flex-grow flex items-center justify-center">
                <p className="text-muted-foreground text-center">Enter a Lichess username to see recent games.</p>
              </div>
            )}
             {!isLoading && !error && games.length === 0 && lichessUsername && (
              <div className="flex-grow flex items-center justify-center">
                <p className="text-muted-foreground text-center">No games found for {lichessUsername} or games are private. <br/> Fetched {games.length} games.</p>
              </div>
            )}

            {games.length > 0 && (
              <ScrollArea className="flex-grow rounded-md border">
                <div className="space-y-2 p-2 sm:p-3">
                  {games.map((game) => {
                    const { playerColor, opponentUsername } = getPlayerPerspective(game, lichessUsername);
                    const result = getPlayerResult(game, playerColor);
                    
                    let playerRatingDisplay = "N/A";
                    const currentPlayerSide = playerColor === 'white' ? game.players.white : (playerColor === 'black' ? game.players.black : null);

                    if (currentPlayerSide && typeof currentPlayerSide.rating === 'number') {
                      if (typeof currentPlayerSide.ratingDiff === 'number') {
                        const preGameRating = currentPlayerSide.rating - currentPlayerSide.ratingDiff;
                        playerRatingDisplay = `${preGameRating} (${currentPlayerSide.ratingDiff >= 0 ? '+' : ''}${currentPlayerSide.ratingDiff})`;
                      } else {
                        playerRatingDisplay = `${currentPlayerSide.rating}`;
                      }
                    }

                    return (
                      <div key={game.id} className="p-2.5 sm:p-3 rounded-md bg-muted/30 border shadow-sm hover:shadow-md transition-shadow duration-150">
                        {/* Row 1: Checkbox and main game info (title, result) */}
                        <div className="flex items-start mb-2">
                          <Checkbox
                            id={`select-${game.id}`}
                            checked={selectedGameIds.includes(game.id)}
                            onCheckedChange={() => handleGameSelectToggle(game.id)}
                            className="mr-3 mt-1 flex-shrink-0 border-slate-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                            aria-label={`Select game ${game.id}`}
                          />
                          {/* Removed individual label to simplify, click on checkbox directly */}
                          <div className="flex-grow">
                            <div className="flex justify-between items-start">
                              <h3 className="text-sm sm:text-base font-semibold leading-tight">
                                vs {opponentUsername}
                                <span className="block sm:inline sm:ml-1 text-xs text-muted-foreground font-normal">({game.variant} / {game.speed})</span>
                              </h3>
                              <span
                                className={`px-1.5 py-0.5 text-[0.7rem] sm:text-xs rounded-full font-medium whitespace-nowrap
                                  ${result.startsWith("Win") ? "bg-green-500/20 text-green-300" : result.startsWith("Loss") ? "bg-red-500/20 text-red-300" : "bg-yellow-500/20 text-yellow-300"}
                                `}
                              >
                                {result}
                              </span>
                            </div>
                            {/* Game details (ID, Color, Rating) - now nested */}
                            <div className="text-[0.7rem] sm:text-xs text-muted-foreground space-y-0.5 mt-1">
                              <div className="flex justify-between items-center">
                                <span><a href={`https://lichess.org/${game.id}`} target="_blank" rel="noopener noreferrer" className="hover:underline text-blue-400">Match ID: {game.id}</a></span>
                                <span>{new Date(game.createdAt).toLocaleDateString()}</span>
                              </div>
                              <div className="flex justify-between items-center">
                                <span>Color: {playerColor.charAt(0).toUpperCase() + playerColor.slice(1)}</span>
                                {game.rated && currentPlayerSide && playerRatingDisplay !== "N/A" && (
                                  <span>{game.perf.charAt(0).toUpperCase() + game.perf.slice(1)}: {playerRatingDisplay}</span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Row for PGN Toggle and Display */}
                        <div className="mt-2">
                          <Button
                            variant="outline"
                            className="text-xs h-7 px-2 py-1"
                            onClick={() => handlePgnVisibilityToggle(game.id)}
                          >
                            {pgnVisibleGameIds.includes(game.id) ? "Hide PGN" : "Show PGN"}
                          </Button>
                          {pgnVisibleGameIds.includes(game.id) && game.moves && (
                            <ScrollArea className="mt-2 p-2 border rounded-md bg-background max-h-40">
                              <pre className="text-xs text-foreground whitespace-pre-wrap break-all">{game.moves}</pre>
                            </ScrollArea>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </div>
        </ResizablePanel>
        <ResizableHandle withHandle className="mx-1 sm:mx-2" />
        <ResizablePanel defaultSize={60} minSize={30} className="p-1 sm:p-2">
          <div className="flex h-full flex-col p-2 sm:p-4 bg-muted/40 rounded-md">
            <h2 className="text-xl font-semibold mb-2 self-start">AI Game Analysis & Chat</h2>
            
            {/* NEW FLEX CONTAINER FOR BUTTON AND TONE SELECTOR */}
            <div className="flex justify-between items-center mb-3">
              {/* Analyze Button on the left */}
              <div> 
                <Button 
                  onClick={handleAnalyzeGame} 
                  disabled={isAnalyzing || selectedGameIds.length === 0 || games.length === 0}
                  className="sm:w-auto text-xs h-7 px-2 py-1" // Removed w-full
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze Selected Game to Chat"}
                </Button>
              </div>
              
              {/* AI Tone Selector on the right */}
              <div className="flex items-center gap-2"> 
                <span className="text-xs text-muted-foreground whitespace-nowrap">AI Tone:</span>
                <Select value={selectedTone} onValueChange={setSelectedTone}>
                  <SelectTrigger className="h-8 text-xs w-auto"> {/* Removed flex-grow, added w-auto */}
                    <SelectValue placeholder="Select tone" />
                  </SelectTrigger>
                  <SelectContent>
                    {toneOptions.map(option => (
                      <SelectItem key={option.value} value={option.value} className="text-xs">
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div ref={chatScrollAreaRef} className="flex-grow border rounded-md p-3 bg-background/50 overflow-y-auto">
              {messages.length === 0 && !isAnalyzing && (
                 <div className="flex flex-col items-center justify-center h-full text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground mb-2">
                        <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                        <path d="M2 17l10 5 10-5"/>
                        <path d="M2 12l10 5 10-5"/>
                        <path d="M12 22V12"/>
                        <circle cx="12" cy="7" r="1"/><circle cx="5" cy="9.5" r="1"/><circle cx="19" cy="9.5" r="1"/><circle cx="5" cy="14.5" r="1"/><circle cx="19" cy="14.5" r="1"/>
                    </svg>
                    <p className="text-sm text-muted-foreground">Analyze a game to start a chat, or type a general chess question below.</p>
                </div>
              )}
              {isAnalyzing && messages.length === 0 && (
                <div className="flex items-center justify-center h-full">
                  <p className="text-muted-foreground italic">Loading analysis from Gemini...</p>
                </div>
              )}
              {messages.map((msg) => (
                <div key={msg.id} className={`mb-3 p-2.5 rounded-lg max-w-[85%] w-fit clear-both ${msg.sender === 'ai' ? 'bg-sky-100 dark:bg-[hsl(180,100%,25%)] text-sky-800 dark:text-[hsl(0,0%,98%)] float-left' : 'bg-blue-500 dark:bg-black text-white float-right ml-auto'}`}>
                  <p className="text-xs font-medium mb-1">{msg.sender === 'ai' ? 'Checkmate.ai' : 'You'}</p>
                  {msg.sender === "ai" ? (
                    <>
                      <ReactMarkdown 
                        className="prose prose-sm dark:prose-invert max-w-none p-1" 
                        remarkPlugins={[remarkGfm]} 
                        rehypePlugins={[rehypeRaw]}
                        components={{}}
                      >
                        {msg.text}
                      </ReactMarkdown>
                      {msg.fen && <ChessboardVisualization fen={msg.fen} />}
                    </>
                  ) : (
                    <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                  )}
                  <p className="text-[0.65rem] text-right mt-1 opacity-70">{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-3 flex flex-col gap-2 pt-3 border-t">
              <div className="flex gap-2">
                <Input 
                  placeholder="ask checkmate.ai"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (handleSendMessage(), e.preventDefault())}
                  className="flex-grow text-sm"
                  disabled={isAnalyzing || isChatProcessing} // Updated to include isChatProcessing
                />
                <Button onClick={handleSendMessage} disabled={isAnalyzing || isChatProcessing || !userInput.trim()} className="text-xs h-7 px-2 py-1">
                  Send
                </Button> 
                <Button onClick={handleRequestVisualization} disabled={isAnalyzing || isChatProcessing || messages.length === 0} className="text-xs h-7 px-2 py-1 bg-purple-600 hover:bg-purple-700">
                  Visualize
                </Button>
              </div>
            </div>
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
      {/* Removed footer placeholder */}
    </div>
  );
}
