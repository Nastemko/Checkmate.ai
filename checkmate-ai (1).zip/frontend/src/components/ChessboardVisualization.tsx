import { Chessboard } from "react-chessboard";

interface Props {
  fen: string;
}

export function ChessboardVisualization({ fen }: Props) {
  return (
    <div style={{ maxWidth: "300px", margin: "20px auto" }}>
      <Chessboard id="chessboard" position={fen} arePiecesDraggable={false} />
    </div>
  );
}