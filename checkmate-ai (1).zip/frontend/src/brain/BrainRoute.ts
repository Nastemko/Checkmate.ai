import {
  AnalyzeGameWithGeminiData,
  ChatMessageRequest,
  ChatRequest,
  CheckHealthData,
  GeminiAnalysisRequest,
  GenerateFenForVisualizationData,
  GetUserGamesData,
  HandleChatMessageData,
  HandleChatwiseMessageRelayData,
} from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Fetches recent games for a Lichess user. - `username`: The Lichess username. - `max_games`: Maximum number of recent games to fetch (default 10).
   * @tags Lichess, dbtn/module:lichess_api, dbtn/hasAuth
   * @name get_user_games
   * @summary Get User Games
   * @request GET:/routes/lichess/users/{username}/games
   */
  export namespace get_user_games {
    export type RequestParams = {
      /** Username */
      username: string;
    };
    export type RequestQuery = {
      /**
       * Max Games
       * @default 10
       */
      max_games?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetUserGamesData;
  }

  /**
   * @description Analyzes a chess game's PGN using Google Gemini to provide colloquial insights.
   * @tags dbtn/module:gemini_analyzer, dbtn/hasAuth
   * @name analyze_game_with_gemini
   * @summary Analyze Game With Gemini
   * @request POST:/routes/analyze-pgn
   */
  export namespace analyze_game_with_gemini {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = GeminiAnalysisRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AnalyzeGameWithGeminiData;
  }

  /**
   * @description Handles a chat message from the user, using the conversation history for context.
   * @tags dbtn/module:gemini_analyzer, dbtn/hasAuth
   * @name handle_chat_message
   * @summary Handle Chat Message
   * @request POST:/routes/chat
   */
  export namespace handle_chat_message {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ChatRequest;
    export type RequestHeaders = {};
    export type ResponseBody = HandleChatMessageData;
  }

  /**
   * No description
   * @tags dbtn/module:chat_handler, dbtn/hasAuth
   * @name handle_chatwise_message_relay
   * @summary Handle Chatwise Message Relay
   * @request POST:/routes/chatwise-message-relay
   */
  export namespace handle_chatwise_message_relay {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ChatMessageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = HandleChatwiseMessageRelayData;
  }

  /**
   * @description This endpoint takes the current conversation history and the user's request for a visual, then calls a specialized Gemini model to generate a FEN string for visualization.
   * @tags dbtn/module:chat_handler, dbtn/hasAuth
   * @name generate_fen_for_visualization
   * @summary Generate Fen For Visualization
   * @request POST:/routes/generate-fen-for-visualization
   */
  export namespace generate_fen_for_visualization {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ChatMessageRequest;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateFenForVisualizationData;
  }
}
