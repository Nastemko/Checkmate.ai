/** ChatMessagePart */
export interface ChatMessagePart {
  /** Text */
  text: string;
}

/** ChatMessageRequest */
export interface ChatMessageRequest {
  /** Message */
  message: string;
  /** Tone Preference */
  tone_preference?: string | null;
  /** Conversation History */
  conversation_history?: AppApisChatHandlerChatMessage[];
}

/** ChatRequest */
export interface ChatRequest {
  /** Conversation History */
  conversation_history: AppApisGeminiAnalyzerChatMessage[];
}

/** ChatResponse */
export interface ChatResponse {
  /** Ai Response */
  ai_response: string;
  /** Model Used */
  model_used: string;
}

/** FenResponse */
export interface FenResponse {
  /** Fen */
  fen: string;
}

/** Game */
export interface Game {
  /** Id */
  id: string;
  /** Rated */
  rated: boolean;
  /** Variant */
  variant: string;
  /** Speed */
  speed: string;
  /** Perf */
  perf: string;
  /** Createdat */
  createdAt: number;
  /** Lastmoveat */
  lastMoveAt: number;
  /** Status */
  status: string;
  players: Players;
  /**
   * Moves
   * @default ""
   */
  moves?: string | null;
  /** Winner */
  winner?: string | null;
}

/** GamesResponse */
export interface GamesResponse {
  /** Username */
  username: string;
  /** Games */
  games: Game[];
  /** Count */
  count: number;
}

/** GeminiAnalysisRequest */
export interface GeminiAnalysisRequest {
  /** Pgn */
  pgn: string;
  /** Tone Preference */
  tone_preference?: string | null;
}

/** GeminiAnalysisResponse */
export interface GeminiAnalysisResponse {
  /** Analysis Text */
  analysis_text: string;
  /** Model Used */
  model_used: string;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** Player */
export interface Player {
  /** User */
  user?: Record<string, any> | null;
  /** Rating */
  rating?: number | null;
  /** Ratingdiff */
  ratingDiff?: number | null;
}

/** Players */
export interface Players {
  white: Player;
  black: Player;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/** ChatMessage */
export interface AppApisChatHandlerChatMessage {
  /** Role */
  role: string;
  /** Parts */
  parts: ChatMessagePart[];
}

/** ChatMessage */
export interface AppApisGeminiAnalyzerChatMessage {
  /** Role */
  role: "user" | "model";
  /** Parts */
  parts: ChatMessagePart[];
}

export type CheckHealthData = HealthResponse;

export interface GetUserGamesParams {
  /**
   * Max Games
   * @default 10
   */
  max_games?: number;
  /** Username */
  username: string;
}

export type GetUserGamesData = GamesResponse;

export type GetUserGamesError = HTTPValidationError;

export type AnalyzeGameWithGeminiData = GeminiAnalysisResponse;

export type AnalyzeGameWithGeminiError = HTTPValidationError;

export type HandleChatMessageData = ChatResponse;

export type HandleChatMessageError = HTTPValidationError;

export type HandleChatwiseMessageRelayData = any;

export type HandleChatwiseMessageRelayError = HTTPValidationError;

export type GenerateFenForVisualizationData = FenResponse;

export type GenerateFenForVisualizationError = HTTPValidationError;
