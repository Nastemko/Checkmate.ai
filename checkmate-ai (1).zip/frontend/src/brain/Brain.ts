import {
  AnalyzeGameWithGeminiData,
  AnalyzeGameWithGeminiError,
  ChatMessageRequest,
  ChatRequest,
  CheckHealthData,
  GeminiAnalysisRequest,
  GenerateFenForVisualizationData,
  GenerateFenForVisualizationError,
  GetUserGamesData,
  GetUserGamesError,
  GetUserGamesParams,
  HandleChatMessageData,
  HandleChatMessageError,
  HandleChatwiseMessageRelayData,
  HandleChatwiseMessageRelayError,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Fetches recent games for a Lichess user. - `username`: The Lichess username. - `max_games`: Maximum number of recent games to fetch (default 10).
   *
   * @tags Lichess, dbtn/module:lichess_api, dbtn/hasAuth
   * @name get_user_games
   * @summary Get User Games
   * @request GET:/routes/lichess/users/{username}/games
   */
  get_user_games = ({ username, ...query }: GetUserGamesParams, params: RequestParams = {}) =>
    this.request<GetUserGamesData, GetUserGamesError>({
      path: `/routes/lichess/users/${username}/games`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Analyzes a chess game's PGN using Google Gemini to provide colloquial insights.
   *
   * @tags dbtn/module:gemini_analyzer, dbtn/hasAuth
   * @name analyze_game_with_gemini
   * @summary Analyze Game With Gemini
   * @request POST:/routes/analyze-pgn
   */
  analyze_game_with_gemini = (data: GeminiAnalysisRequest, params: RequestParams = {}) =>
    this.request<AnalyzeGameWithGeminiData, AnalyzeGameWithGeminiError>({
      path: `/routes/analyze-pgn`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Handles a chat message from the user, using the conversation history for context.
   *
   * @tags dbtn/module:gemini_analyzer, dbtn/hasAuth
   * @name handle_chat_message
   * @summary Handle Chat Message
   * @request POST:/routes/chat
   */
  handle_chat_message = (data: ChatRequest, params: RequestParams = {}) =>
    this.request<HandleChatMessageData, HandleChatMessageError>({
      path: `/routes/chat`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * No description
   *
   * @tags dbtn/module:chat_handler, dbtn/hasAuth
   * @name handle_chatwise_message_relay
   * @summary Handle Chatwise Message Relay
   * @request POST:/routes/chatwise-message-relay
   */
  handle_chatwise_message_relay = (data: ChatMessageRequest, params: RequestParams = {}) =>
    this.request<HandleChatwiseMessageRelayData, HandleChatwiseMessageRelayError>({
      path: `/routes/chatwise-message-relay`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description This endpoint takes the current conversation history and the user's request for a visual, then calls a specialized Gemini model to generate a FEN string for visualization.
   *
   * @tags dbtn/module:chat_handler, dbtn/hasAuth
   * @name generate_fen_for_visualization
   * @summary Generate Fen For Visualization
   * @request POST:/routes/generate-fen-for-visualization
   */
  generate_fen_for_visualization = (data: ChatMessageRequest, params: RequestParams = {}) =>
    this.request<GenerateFenForVisualizationData, GenerateFenForVisualizationError>({
      path: `/routes/generate-fen-for-visualization`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });
}
