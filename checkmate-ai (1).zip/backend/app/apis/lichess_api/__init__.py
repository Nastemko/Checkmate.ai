from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests
import json # For parsing NDJSON lines
from typing import List, Optional, Dict, Any

router = APIRouter(prefix="/lichess", tags=["Lichess"])

# --- Pydantic Models ---
class Player(BaseModel):
    user: Optional[Dict[str, Any]] = None # Lichess provides a nested user object
    rating: Optional[int] = None
    ratingDiff: Optional[int] = None

class Players(BaseModel):
    white: Player
    black: Player

class Game(BaseModel):
    id: str
    rated: bool
    variant: str
    speed: str
    perf: str
    createdAt: int # Timestamp
    lastMoveAt: int # Timestamp
    status: str
    players: Players
    moves: Optional[str] = "" # PGN of moves, can be long
    winner: Optional[str] = None # 'white', 'black', or None for draw
    # We can add more fields from Lichess API as needed
    # Example: opening, clock, evals etc.

class GamesResponse(BaseModel):
    username: str
    games: List[Game]
    count: int

# --- API Endpoint ---
@router.get("/users/{username}/games", response_model=GamesResponse)
def get_user_games(username: str, max_games: int = 10):
    """
    Fetches recent games for a Lichess user.
    - `username`: The Lichess username.
    - `max_games`: Maximum number of recent games to fetch (default 10).
    """
    lichess_api_url = f"https://lichess.org/api/games/user/{username}"
    headers = {
        "Accept": "application/x-ndjson" # Lichess API returns NDJSON
    }
    params = {
        "max": max_games,
        "tags": "true",       # Include game tags
        "clocks": "false",    # Exclude clock data for now
        "evals": "false",     # Exclude evaluations for now
        "opening": "true",   # Include opening name
        "literate": "true",   # Include PGN moves, might be useful later
        # "pgnInJson": "true" # This would put PGN in a JSON field, but literate=true gives it directly
    }

    print(f"Fetching games for {username} from {lichess_api_url} with params: {params}")

    try:
        response = requests.get(lichess_api_url, headers=headers, params=params, stream=True)
        response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)

        games_data: List[Game] = []
        for line in response.iter_lines():
            if line:
                try:
                    game_json = json.loads(line.decode('utf-8'))
                    # Basic validation/transformation if needed before Game model parsing
                    # For example, Lichess 'createdAt' and 'lastMoveAt' are timestamps
                    # and 'moves' can be a very long string (PGN)
                    
                    # Directly parse into Pydantic model
                    # We might need to be more selective or handle missing fields if the API is inconsistent
                    # For now, let's assume the fields match our Game model for simplicity
                    game = Game(**game_json)
                    games_data.append(game)
                except json.JSONDecodeError:
                    print(f"Warning: Could not decode JSON line: {line}")
                except Exception as e:
                    # Catch Pydantic validation errors or other issues
                    print(f"Error processing game data: {game_json}. Error: {e}")
                    # Optionally skip this game or handle more gracefully
            
            if len(games_data) >= max_games: # Ensure we don't exceed max_games from stream
                break
        
        if not games_data and response.status_code == 200:
            # No games found, but request was successful
            print(f"No games found for user {username} with current filters.")

        return GamesResponse(
            username=username,
            games=games_data,
            count=len(games_data)
        )

    except requests.exceptions.HTTPError as http_err:
        if response.status_code == 404:
            raise HTTPException(status_code=404, detail=f"Lichess user '{username}' not found or no games available with current filters.")
        else:
            print(f"HTTP error occurred: {http_err} - {response.text}")
            raise HTTPException(status_code=response.status_code, detail=f"Error fetching data from Lichess API: {response.text}")
    except requests.exceptions.RequestException as req_err:
        print(f"Request error occurred: {req_err}")
        raise HTTPException(status_code=503, detail=f"Error connecting to Lichess API: {req_err}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        raise HTTPException(status_code=500, detail=f"An unexpected server error occurred: {e}")

# Example usage (for testing locally, not part of the API itself):
# if __name__ == "__main__":
#     # This part is for local testing and won't run in Databutton's FastAPI environment
#     sample_username = "Boatcrouchstem"
#     # sample_username = "thisuserdoesnotexist12345"
#     try:
#         games_response = get_user_games(sample_username, max_games=5)
#         print(f"Successfully fetched {games_response.count} games for {games_response.username}.")
#         for game in games_response.games:
#             print(f"- Game ID: {game.id}, Variant: {game.variant}, Status: {game.status}, Winner: {game.winner}")
#     except HTTPException as e:
#         print(f"API Error: {e.status_code} - {e.detail}")
