from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional 
import google.generativeai as genai # Reinstated
import databutton as db

router = APIRouter() 

class ChatMessagePart(BaseModel):
    text: str

class ChatMessage(BaseModel):
    role: str  
    parts: List[ChatMessagePart]

class ChatMessageRequest(BaseModel):
    message: str
    tone_preference: str | None = None
    conversation_history: List[ChatMessage] = Field(default_factory=list)

class ChatResponse(BaseModel):
    reply: str

class FenResponse(BaseModel):
    fen: str

@router.post("/chatwise-message-relay")
async def handle_chatwise_message_relay(request: ChatMessageRequest):
    print(f"[CHAT_HANDLER_DEBUG] Relay request received: {request.model_dump_json(indent=2)}")
    api_key = db.secrets.get("GEMINI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY not configured")

    genai.configure(api_key=api_key)

    gemini_history = []
    if request.conversation_history:
        for msg in request.conversation_history:
            formatted_parts = []
            if msg.parts:
                for part in msg.parts:
                    formatted_parts.append({"text": part.text})
            gemini_history.append({"role": msg.role, "parts": formatted_parts})
    
    print(f"[CHAT_HANDLER_DEBUG] Prepared gemini_history: {gemini_history}")

    tone_instructions = {
        "Friendly & Casual": "Respond in a friendly, casual, and encouraging manner. Explain concepts simply.",
        "Simple & Direct": "Be concise and to the point. Use simple language.",
        "Encouraging Coach": "Adopt a supportive and motivational tone, like a helpful chess coach.",
        "Technical & In-depth": "Provide detailed, technical explanations using precise chess terminology."
    }
    
    current_tone_instruction = tone_instructions.get(request.tone_preference or "Friendly & Casual", tone_instructions["Friendly & Casual"])

    system_message_content = f"""You are ChessWise AI, a helpful chess assistant. 
    {current_tone_instruction}
    The user may ask about a previous game analysis or general chess topics. 
    The user may provide a PGN for analysis. If a PGN is provided in the user's message, base your analysis and subsequent discussion on this PGN.
    Keep your responses relevant to chess and the ongoing conversation.
    """

    model_with_system_prompt = genai.GenerativeModel(
        model_name='gemini-2.0-flash',
        system_instruction=system_message_content
    )
    chat_session = model_with_system_prompt.start_chat(history=gemini_history)

    try:
        if not request.message:
             raise HTTPException(status_code=400, detail="Message cannot be empty.")
        response = await chat_session.send_message_async(request.message)
        
        reply_text = ""
        if response.parts:
            reply_text = ' '.join(part.text for part in response.parts if hasattr(part, 'text'))
        elif hasattr(response, 'text'): 
             reply_text = response.text

        if not reply_text and not (hasattr(response, 'candidates') and response.candidates):
            print(f"Gemini API returned no parsable text in chat. Full response: {response}")
            finish_reason = "Unknown"
            if hasattr(response, 'candidates') and response.candidates and hasattr(response.candidates[0], 'finish_reason') and response.candidates[0].finish_reason:
                finish_reason = response.candidates[0].finish_reason.name
            if finish_reason == "SAFETY":
                 raise HTTPException(status_code=400, detail="Your message was blocked by safety filters.")
            else:
                 raise HTTPException(status_code=500, detail=f"Gemini API returned an empty or unparsable reply. Finish reason: {finish_reason}")
        
        print(f"[CHAT_HANDLER_DEBUG] Gemini reply: {reply_text}")
        return ChatResponse(reply=reply_text)
    except Exception as e:
        print(f"Error calling Gemini API during chat: {e}")
        error_message = str(e)
        if isinstance(e, HTTPException):
            raise e
        if "safety settings" in error_message.lower() or "SAFETY" in error_message.upper():
            error_message = "Your message could not be processed due to safety filters. Please rephrase your message."
        elif "API key not valid" in error_message:
            error_message = "The Gemini API key is invalid. Please check the configuration."
        raise HTTPException(status_code=500, detail=f"Failed to get chat reply: {error_message}")

@router.post("/generate-fen-for-visualization", response_model=FenResponse)
async def generate_fen_for_visualization(request: ChatMessageRequest):
    """
    This endpoint takes the current conversation history and the user's request for a visual,
    then calls a specialized Gemini model to generate a FEN string for visualization.
    """
    print(f"[FEN_GENERATOR_DEBUG] Request received: {request.model_dump_json(indent=2)}")
    api_key = db.secrets.get("GEMINI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY not configured")

    genai.configure(api_key=api_key)

    # Prepare the conversation history for the model
    gemini_history = []
    if request.conversation_history:
        for msg in request.conversation_history:
            # Ensure parts are correctly formatted
            formatted_parts = [{"text": part.text} for part in msg.parts if hasattr(part, 'text')]
            gemini_history.append({"role": msg.role, "parts": formatted_parts})

    # System prompt to instruct the model to act as a FEN generator
    system_prompt = (
        "You are an expert chess analyst. Your sole task is to act as a FEN (Forsyth-Edwards Notation) generator. "
        "Based on the provided chess game PGN and the ongoing conversation, you must provide ONLY the FEN string "
        "for the board state being discussed or requested. Do not include any other text, explanations, or formatting. "
        "Your entire response must be the FEN string and nothing else. For example: rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    )

    model_with_system_prompt = genai.GenerativeModel(
        model_name='gemini-1.5-pro-latest',
        system_instruction=system_prompt
    )
    
    chat_session = model_with_system_prompt.start_chat(history=gemini_history)

    try:
        # The user's latest message is the prompt for the FEN generation
        if not request.message:
            raise HTTPException(status_code=400, detail="Message for FEN generation cannot be empty.")
            
        response = await chat_session.send_message_async(request.message)
        
        fen_string = ""
        if response.parts:
            fen_string = ' '.join(part.text for part in response.parts if hasattr(part, 'text')).strip()
        elif hasattr(response, 'text'):
            fen_string = response.text.strip()

        if not fen_string:
            raise HTTPException(status_code=500, detail="Failed to generate a FEN string from the model.")

        print(f"[FEN_GENERATOR_DEBUG] Generated FEN: {fen_string}")
        return FenResponse(fen=fen_string)

    except Exception as e:
        print(f"Error calling Gemini API for FEN generation: {e}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"Failed to generate FEN: {str(e)}")


