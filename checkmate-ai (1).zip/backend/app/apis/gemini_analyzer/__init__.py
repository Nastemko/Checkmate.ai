import databutton as db
import google.generativeai as genai
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal, List, Optional

router = APIRouter()

# --- Pydantic Models for /analyze-pgn ---
class GeminiAnalysisRequest(BaseModel):
    pgn: str
    tone_preference: str | None = None

class GeminiAnalysisResponse(BaseModel):
    analysis_text: str
    model_used: str


# --- Pydantic Models for /chat ---
class ChatMessagePart(BaseModel):
    text: str # Gemini API expects "text" field for parts

class ChatMessage(BaseModel):
    role: Literal["user", "model"]
    parts: List[ChatMessagePart]

class ChatRequest(BaseModel):
    conversation_history: List[ChatMessage]
    # pgn_context: Optional[str] = None # Could be added if we want to explicitly pass PGN for every chat turn

class ChatResponse(BaseModel):
    ai_response: str
    model_used: str


# --- Helper: Configure Gemini ---
def get_gemini_model():
    try:
        api_key = db.secrets.get("GEMINI_API_KEY")
        if not api_key:
            print("Error: GEMINI_API_KEY not found in secrets.")
            raise HTTPException(status_code=500, detail="Gemini API key not configured.")
        
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash')
        return model
    except Exception as e:
        print(f"Error configuring Gemini: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to configure Gemini: {str(e)}")

# --- API Endpoint ---
@router.post("/analyze-pgn", response_model=GeminiAnalysisResponse)
async def analyze_game_with_gemini(request: GeminiAnalysisRequest):
    """
    Analyzes a chess game's PGN using Google Gemini to provide colloquial insights.
    """
    if not request.pgn or not request.pgn.strip():
        raise HTTPException(status_code=400, detail="PGN data cannot be empty.")

    try:
        model = get_gemini_model()
        
        # Construct the prompt
        # This prompt needs careful crafting and iteration for best results.
        # We can refine this based on the quality of analysis we get.
        prompt_parts = [
            "You are ChessWise, an AI assistant for casual chess players.",
            "Analyze the following chess game provided in PGN format.",
            "Explain the player's gameplay trends in simple, colloquial terms, as if you were a friendly chess coach talking to a friend.",
            "Avoid technical chess jargon as much as possible. For instance, instead of saying 'Sicilian Defense, Najdorf Variation', you might say 'You often like to respond to the king's pawn opening with a specific setup on the queenside'.",
            "Keep the analysis concise, friendly, and encouraging.",
            "Format your entire response using Markdown.",
            "Include the following sections with Markdown headings:",
            "### Overall Summary",
            "  Provide a brief, 1-2 sentence encouraging overview of the game analyzed.",
            "### Key Patterns & Tendencies",
            "  - Use bullet points to list 2-4 notable observations about the player\'s style, common mistakes, or strategic choices based on THIS game.",
            "  - Example: '- You seemed to control the center well in the early middlegame.'",
            "  - Example: '- There was a moment around move 25 where a different knight move could have been stronger.'",
            "### Opening Style",
            "  - Briefly describe the opening approach in THIS game in simple terms. Avoid highly technical opening names.",
            "  - Example: 'You went for a quick attack on the kingside after the opening.'",
            "### Improvement Focus for Next Game",
            "  - Suggest 1-2 specific, actionable areas for improvement based on THIS game, explained simply.",
            "  - Example: '- Look out for opportunities to use pins more effectively.'",
            "  - Example: '- Before moving a piece, double-check if it leaves another piece undefended.'",
            "Focus ONLY on the single game provided in the PGN. Do not make assumptions about other games.",
            "Here is the PGN data for the game to analyze:",
            request.pgn
        ]
        
        # if request.user_prompt_supplement:
        #     prompt_parts.append(f"\nAdditionally, the user specifically asked: {request.user_prompt_supplement}")

        print(f"Sending PGN (first 100 chars): {request.pgn[:100]}... to Gemini for analysis.")
        
        response = model.generate_content(prompt_parts)
        
        analysis = response.text
        
        print(f"Gemini analysis received (first 100 chars): {analysis[:100]}...")
        
        return GeminiAnalysisResponse(analysis_text=analysis, model_used='gemini-2.0-flash')

    except HTTPException as e:
        # Re-raise HTTPExceptions to ensure FastAPI handles them correctly
        raise e
    except Exception as e:
        print(f"Error during Gemini API call: {e}")
        # Log the full error for debugging on the server
        # Consider what error detail is safe to return to the client
        raise HTTPException(status_code=500, detail=f"An error occurred while analyzing the game: {str(e)}")

# Ensure the directory structure is src/app/apis/gemini_analyzer/__init__.py


# --- API Endpoint for Chat ---
@router.post("/chat", response_model=ChatResponse)
async def handle_chat_message(request: ChatRequest):
    """
    Handles a chat message from the user, using the conversation history for context.
    """
    if not request.conversation_history:
        raise HTTPException(status_code=400, detail="Conversation history cannot be empty.")

    try:
        model = get_gemini_model() # Reuse existing helper

        # The system prompt for general chat tone is implicitly set by the initial analysis prompt.
        # If the conversation_history is fresh (e.g., only user message), or if we want to reinforce, 
        # we could prepend a system message, but Gemini's chat model is good at picking up context.
        
        # Ensure the history is in the format Gemini expects (list of Content objects or dicts)
        # Our ChatMessage model is designed to be compatible.
        formatted_history = []
        for msg in request.conversation_history[:-1]: # All but the last message which is the current user query
            formatted_history.append({
                "role": msg.role,
                "parts": [p.text for p in msg.parts]
            })

        current_user_message_text = ""
        if request.conversation_history[-1].role == "user" and request.conversation_history[-1].parts:
            current_user_message_text = request.conversation_history[-1].parts[0].text
        else:
            # This case should ideally not happen if frontend structures requests correctly
            raise HTTPException(status_code=400, detail="Last message in history must be from user and contain text.")

        if not current_user_message_text.strip():
             raise HTTPException(status_code=400, detail="User message cannot be empty.")

        print(f"Starting chat with history (num messages): {len(formatted_history)}")
        print(f"Current user message to send: {current_user_message_text[:100]}...")

        # Start a chat session with the history (excluding the current user message to be sent)
        chat_session = model.start_chat(history=formatted_history)
        
        # Send the current user's message
        # The system prompt defining ChessWise's persona is assumed to be part of the initial messages in the history
        # or implicitly understood by Gemini from the ongoing conversation style.
        # If the initial message (the analysis) is not in `formatted_history` because it's the first user message *after* analysis,
        # then the context from the analysis is lost unless we explicitly pass it or ensure frontend sends it.
        # For now, we assume frontend sends the full history including the initial AI analysis message.
        
        gemini_response = chat_session.send_message(current_user_message_text)
        ai_text_response = gemini_response.text

        print(f"Gemini chat response received (first 100 chars): {ai_text_response[:100]}...")

        return ChatResponse(ai_response=ai_text_response, model_used='gemini-2.0-flash')

    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Error during Gemini chat API call: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred during chat: {str(e)}")
